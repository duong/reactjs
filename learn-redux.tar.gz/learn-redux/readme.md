# Learn React, Redux, Wepack, ES6

A simple React + Redux implementation. This will be show a list of images list

## Running

First `npm install` to grab all the necessary dependencies. 

Then run `npm start` and open <localhost:8088> in your browser.

## Production Build

Run `npm build` to create a distro folder and a bundle.js file.


## Mongo db
First install mongo db on your local with default port 27017 and start it